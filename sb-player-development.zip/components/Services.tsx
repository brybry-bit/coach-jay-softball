
import React from 'react';
import { TrainingType } from '../types';
import { HittingIcon, CatchingIcon, FieldingIcon } from './icons';

interface Service {
  type: TrainingType;
  icon: React.ReactNode;
  description: string;
}

const services: Service[] = [
  {
    type: TrainingType.Hitting,
    icon: <HittingIcon className="h-10 w-10 text-softball-yellow mb-4" />,
    description: "Refine your swing mechanics, timing, and plate approach with high-rep sessions against live college-level pitching."
  },
  {
    type: TrainingType.Catching,
    icon: <CatchingIcon className="h-10 w-10 text-softball-yellow mb-4" />,
    description: "Improve your framing, blocking, and game-calling skills by catching collegiate pitchers in a controlled, instructional setting."
  },
  {
    type: TrainingType.Fielding,
    icon: <FieldingIcon className="h-10 w-10 text-softball-yellow mb-4" />,
    description: "Develop gold-glove caliber fundamentals, footwork, and reaction time through D1-level infield and outfield drills."
  }
];

const ServiceCard: React.FC<{ service: Service }> = ({ service }) => (
  <div className="bg-slate-800/50 p-8 rounded-lg shadow-xl hover:-translate-y-2 transition-transform duration-300 flex flex-col items-start">
    {service.icon}
    <h3 className="text-2xl font-bold text-light-slate mb-3">{service.type}</h3>
    <p className="text-slate-gray">{service.description}</p>
  </div>
);

const Services: React.FC = () => {
  return (
    <section id="services" className="py-24">
      <h2 className="text-3xl font-bold text-center text-light-slate mb-12">
        <span className="text-softball-yellow font-mono mr-2">01.</span> My Services
      </h2>
      <div className="grid md:grid-cols-3 gap-8">
        {services.map(service => (
          <ServiceCard key={service.type} service={service} />
        ))}
      </div>
    </section>
  );
};

export default Services;
