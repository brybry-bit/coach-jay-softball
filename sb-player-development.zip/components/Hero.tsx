
import React from 'react';

const Hero: React.FC = () => {
  const scrollToSchedule = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    document.querySelector('#schedule')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="min-h-screen flex items-center pt-20">
      <div className="w-full">
        <h1 className="text-softball-yellow font-mono text-lg md:text-xl mb-4">Hi, I'm Coach Jay.</h1>
        <h2 className="text-4xl md:text-6xl lg:text-7xl font-black text-light-slate mb-4">
          Elite Training for the<br />Next Generation of Ballplayers.
        </h2>
        <h3 className="text-3xl md:text-5xl lg:text-6xl font-black text-slate-gray mb-8">
          Face College Pitchers. Elevate Your Game.
        </h3>
        <p className="max-w-xl text-lg mb-12">
          As the Director of Player Development at a D1 program, I bring elite-level training to dedicated middle and high school athletes. My program is the only one where you'll get consistent at-bats and catching reps against current college pitchers.
        </p>
        <div>
          <a href="#schedule" onClick={scrollToSchedule} className="px-8 py-4 border border-softball-yellow text-softball-yellow rounded font-mono text-lg hover:bg-softball-yellow/10 transition-colors duration-300">
            Schedule a Session
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
